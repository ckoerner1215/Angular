import { Module } from './module.model';

describe('Module', () => {
  it('should create an instance', () => {
    expect(new Module()).toBeTruthy();
  });
});
