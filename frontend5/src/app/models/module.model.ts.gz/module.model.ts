export class Module {
  id?: any;
  title?: string;
  description?: string;
  published?: boolean;
}
